package com.music.bitchord.data

import com.music.bitchord.data.sources.SourceTrackKeys
import com.music.bitchord.data.sources.StreamFormat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.util.concurrent.ConcurrentHashMap

/**
 * Architectural provenance of audio pipeline telemetry statistics.
 */
enum class TelemetryProvenance {
    AUTHORITATIVE,
    MEASURED,
    DERIVED,
    UNKNOWN,
}

/**
 * What the audio decoder is actually being fed, for "stats for nerds".
 *
 * Every figure here is measured rather than inferred, and every label derived
 * from them — "High Quality", "Lossless", "Hi-Res Lossless" — is decided on
 * the measurements alone. Codec, sample rate, channel count and depth come
 * from the `Format` the audio renderer was configured with, topped up from the
 * stream's own header where its container left them blank; see
 * `PlaybackService.measure`. Bitrate is the one a container usually withholds,
 * so a lossless stream reports what its samples decode to and a lossy one
 * falls back to the bitrate of the stream the resolver genuinely chose for
 * that track. Anything the player hasn't reported stays null and is left out
 * of the display instead of being guessed at.
 *
 * [claimed] is the one figure here that is *not* measured, and is kept apart
 * from the rest for that reason: it is what a source said it was about to send.
 * Holding both is the point — a source promising 24-bit/192kHz while the
 * decoder reports 16-bit/48kHz is the single most likely way for a lossless
 * setting to be quietly doing nothing, and it is invisible unless the two
 * numbers are put side by side. See [downgraded].
 */
object NerdStats {

    class Snapshot(
        val mimeType: String?,
        val bitrateKbps: Int?,
        val sampleRateHz: Int?,
        val channels: Int?,
        /** From the decoder's PCM encoding, where it states one. */
        val bitDepth: Int? = null,
        /** What the source said it would serve, when it came from one that says. */
        val claimed: StreamFormat? = null,
        /** Authoritative source/provider that supplied this stream. */
        val sourceName: String? = null,
        /**
         * The file's container where it says something the codec doesn't —
         * "DSF" or "DFF" for DSD, which reaches the decoder as plain PCM.
         */
        val container: String? = null,
        /** Provenance of the displayed source/encoded bitrate. */
        val bitrateProvenance: TelemetryProvenance = TelemetryProvenance.UNKNOWN,
        /** True PCM throughput (sampleRate * bitDepth * channels / 1000). Never conflated with encoded bitrate. */
        val pcmDataRateKbps: Int? = null,
    ) {
        /**
         * Whether what arrived is measurably worse than what was promised.
         *
         * Only ever true when both figures are known — an absent measurement is
         * not evidence of a downgrade, and reporting one on that basis would
         * make the warning worthless the moment it fired on a container that
         * simply doesn't state its rate.
         */
        val downgraded: Boolean
            get() {
                val wantedRate = claimed?.sampleRateHz
                val wantedDepth = claimed?.bitDepth
                return (wantedRate != null && sampleRateHz != null && sampleRateHz < wantedRate) ||
                    (wantedDepth != null && bitDepth != null && bitDepth < wantedDepth)
            }

        /**
         * Whether the decoder is genuinely being fed a lossless codec — the
         * figure the Now Playing screen's "Lossless" badge is gated on, not
         * just what a source promised. [claimed] alone would let a source
         * that said "FLAC" and quietly served Opus still light the badge.
         *
         * Which is exactly what it did, because this was written as
         * `claimed?.isLossless == true || …` — the claim on its own, the very
         * thing the paragraph above says it must not be. Observed: an upgrade
         * to a Tidal FLAC was served, recorded as the declared format, and
         * then died on `ERROR_CODE_IO_BAD_HTTP_STATUS`; playback recovered
         * onto YouTube's Opus and the badge went on reading "Lossless" over
         * it, because the claim outlived the stream that made it.
         *
         * So the decoder gets the only word. The claim used to stand in
         * before the renderer had been configured, on the grounds that a
         * wrong answer there lasts a second rather than a song; it no longer
         * does. A second of a badge that turns out to be wrong is still a
         * badge that was wrong, [current] is nulled across a track change so
         * that gap shows nothing rather than the previous track's figures,
         * and "measured or not stated" is a rule that can be read off the
         * screen — "measured, except briefly, when it is whatever the module
         * said" is not.
         */
        val isLossless: Boolean
            get() = isLosslessMime(mimeType)

        /** Dolby Atmos decoded as E-AC-3 JOC; deliberately distinct from lossless. */
        val isDolbyAtmos: Boolean
            get() = isDolbyAtmosMime(mimeType)

        /**
         * Whether this is better than CD quality — the line Tidal, Qobuz and
         * Apple Music all draw it at: past 16-bit or past 48kHz, not merely
         * lossless. A 16-bit/44.1kHz FLAC is a bit-exact CD rip and gets
         * called "Lossless"; a 24-bit/96kHz one is "Hi-Res Lossless", because
         * calling both the same thing would flatten a distinction the
         * listener can plausibly hear.
         */
        val isHiRes: Boolean
            get() = isLossless && ((bitDepth ?: 0) > 16 || (sampleRateHz ?: 0) > 48_000)

        /**
         * Whether this is lossy, but at the top of what lossy gets — a 320kbps
         * AAC or MP3 from a module's HIGH tier, rather than YouTube's 160kbps
         * Opus.
         *
         * Worth naming on screen because it is the honest answer often enough
         * to matter: plenty of catalogues simply have no lossless copy of a
         * track, and a badge with only two states — "Lossless" or nothing —
         * makes a good stream and a mediocre one look identical. Not called
         * lossless anywhere, because it isn't.
         *
         * Decided on the bitrate rather than on which source served it: a
         * 256kbps stream is a 256kbps stream wherever it came from — and on
         * [bitrateKbps] rather than on [claimed], for the reason [isLossless]
         * gives at length. A module that offers a LOSSLESS tier and then
         * serves SoundCloud at 128kbps is the ordinary case here, not the
         * exotic one.
         */
        val isHiQuality: Boolean
            get() = !isLossless && (bitrateKbps ?: 0) >= HI_QUALITY_KBPS

        /**
         * Whether this is a medium quality stream (e.g. YouTube Opus ~160kbps, AAC 128-192kbps).
         * Sits strictly between low-quality (<= 80kbps) and high-quality (>= 256kbps).
         */
        val isMediumQuality: Boolean
            get() = !isLossless && (bitrateKbps ?: 0) in (LOW_QUALITY_MAX_KBPS + 1) until HI_QUALITY_KBPS

        /**
         * Whether this is a low quality stream (e.g. YouTube Opus 50-70kbps).
         */
        val isLowQuality: Boolean
            get() = !isLossless && (bitrateKbps ?: 0) in 1..LOW_QUALITY_MAX_KBPS
    }

    /**
     * What the renderer's input mime type looks like when the bytes behind it
     * are bit-exact.
     *
     * `audio/raw` is here because that is how Media3 names PCM — a WAV stream
     * reaches the renderer as raw samples, not as `audio/wav`.
     */
    private val LOSSLESS_CODEC_SUFFIXES = listOf("flac", "alac", "raw")

    /**
     * Whether [mimeType] names a bit-exact codec.
     *
     * Exposed because the decoder's own verdict is also what decides whether a
     * track playing from the disk cache is worth hunting a better copy of — see
     * [QualityUpgrade.adoptUnresolved][com.music.bitchord.playback.QualityUpgrade.adoptUnresolved].
     * Reading [Snapshot.isLossless] there instead would mean trusting whichever
     * track the last [current] publish happened to describe, which after a
     * queue advance is the previous one.
     */
    fun isLosslessMime(mimeType: String?): Boolean =
        mimeType != null && (LOSSLESS_CODEC_SUFFIXES.any { mimeType.endsWith(it) } || mimeType.startsWith("audio/dsd"))

    /**
     * A rate of a megahertz or more, as DSD's are named: 2822400 -> "2.8224 MHz".
     * Null below that, where each caller keeps its own kHz wording. Exact
     * digits rather than one decimal place, since the DSD rates are all
     * multiples of 44.1 kHz and rounding them makes them unrecognisable.
     */
    fun megahertzLabel(hz: Int): String? =
        if (hz < 1_000_000) null
        else java.math.BigDecimal(hz).movePointLeft(6).stripTrailingZeros().toPlainString() + " MHz"

    fun isDolbyAtmosMime(mimeType: String?): Boolean =
        mimeType != null && (mimeType.endsWith("eac3-joc") || mimeType.endsWith("eac3"))

    fun isRawPcm(mimeType: String?): Boolean =
        mimeType != null && (mimeType == "audio/raw" || mimeType.endsWith("wav", ignoreCase = true) || mimeType == "audio/x-wav")

    /**
     * The upper bound in kbps for a low-bitrate / data-saver lossy stream.
     */
    const val LOW_QUALITY_MAX_KBPS = 80

    /**
     * The bitrate a lossy stream has to reach to be worth calling out.
     *
     * At 256 an Apple-style AAC counts and YouTube's Opus, which tops out
     * around 160, does not — which is the distinction the label exists to
     * draw.
     */
    const val HI_QUALITY_KBPS = 256

    fun codecLabel(mimeType: String?): String? {
        if (mimeType == null) return null
        return when {
            mimeType.endsWith("flac", ignoreCase = true) -> "FLAC"
            mimeType.endsWith("opus", ignoreCase = true) -> "Opus"
            mimeType.endsWith("mp4a-latm", ignoreCase = true) || mimeType.endsWith("aac", ignoreCase = true) -> "AAC"
            mimeType.endsWith("mpeg", ignoreCase = true) || mimeType.endsWith("mp3", ignoreCase = true) -> "MP3"
            mimeType.endsWith("alac", ignoreCase = true) -> "ALAC"
            mimeType.endsWith("raw", ignoreCase = true) -> "PCM"
            mimeType.startsWith("audio/dsd", ignoreCase = true) -> mimeType.substringAfter('/').uppercase()
            mimeType.endsWith("vorbis", ignoreCase = true) -> "Vorbis"
            mimeType.endsWith("eac3-joc", ignoreCase = true) -> "E-AC-3 JOC"
            mimeType.endsWith("eac3", ignoreCase = true) -> "E-AC-3"
            mimeType.contains("/") -> mimeType.substringAfterLast("/").uppercase()
            else -> mimeType.uppercase()
        }
    }

    val current = MutableStateFlow<Snapshot?>(null)

    /**
     * YouTube video ids with a module lookup racing YouTube's own resolve
     * for the stream to actually play — see
     * [PlaybackService][com.music.bitchord.playback.PlaybackService]'s
     * resolving data source. Both start together and whichever answers first
     * plays; the module is the one still worth hearing about, because a
     * YouTube win only means the search continues under the music — so this
     * is what the UI shows "looking for a better copy" from. A track leaves
     * the set the moment its own lookup settles either way, never on a timer.
     */
    val racingLossless = MutableStateFlow<Set<String>>(emptySet())

    fun onLosslessRaceStart(videoId: String) {
        // Upgrade lookups also run for read-ahead items, so two loader threads
        // can arrive here together. Assigning `value += videoId` is a
        // read/modify/write sequence: both threads can read the same old set and
        // the last assignment then erases the other track's marker. That left
        // the audible track upgrading in the background while Now Playing fell
        // through to its plain "High quality" label. StateFlow.update retries
        // the transform atomically when another writer wins that race.
        racingLossless.update { it + videoId }
    }

    fun onLosslessRaceEnd(videoId: String) {
        // Atomic for the same reason as start: completing one read-ahead lookup
        // must not discard a concurrently-started lookup for another track.
        racingLossless.update { it - videoId }
    }

    /**
     * Bitrate in kbps of the stream picked for each videoId.
     *
     * Keyed by track rather than kept as a single "last picked": the read-ahead
     * resolves the *next* track through the same code, so one loose value would
     * end up describing the wrong song.
     */
    private val picked = ConcurrentHashMap<String, Int>()

    /** As [picked], for the richer format a non-YouTube source can state. */
    private val declared = ConcurrentHashMap<String, StreamFormat>()

    /** Authoritative source name that supplied the stream, keyed by media/track id. */
    private val sources = ConcurrentHashMap<String, String>()

    fun onStreamPicked(videoId: String, kbps: Int, source: String? = null) {
        if (kbps > 0) {
            // Enough for the queue in hand; this is a lookup, not a store.
            if (picked.size >= MAX_REMEMBERED) picked.clear()
            picked[videoId] = kbps
        }
        if (!source.isNullOrBlank()) {
            if (sources.size >= MAX_REMEMBERED) sources.clear()
            sources[videoId] = source
        }
    }

    /** Recorded as a source hands over a stream, keyed by that source's own track id. */
    fun onSourceStream(trackId: String?, format: StreamFormat, source: String? = null) {
        if (trackId.isNullOrBlank()) return
        if (declared.size >= MAX_REMEMBERED) declared.clear()
        declared[trackId] = format
        if (!source.isNullOrBlank()) {
            if (sources.size >= MAX_REMEMBERED) sources.clear()
            sources[trackId] = source
        }
    }

    fun recordSource(mediaId: String?, source: String?) {
        if (mediaId.isNullOrBlank() || source.isNullOrBlank()) return
        if (sources.size >= MAX_REMEMBERED) sources.clear()
        sources[mediaId] = source
    }

    fun exactSourceFor(mediaId: String?): String? = mediaId?.let { sources[it] }

    fun sourceFor(mediaId: String?): String? {
        val key = mediaId ?: return null
        return sources[key]
            ?: SourceTrackKeys.parse(key)?.second?.let { sources[it] }
    }

    fun pickedBitrateKbps(videoId: String?): Int? = videoId?.let { picked[it] }

    /**
     * Undoes [onSourceStream] for [trackId].
     *
     * For when a swap to a claimed-better stream doesn't pan out and the
     * player falls back to what it had — see
     * [PlaybackService][com.music.bitchord.playback.PlaybackService]'s
     * upgrade revert. Without this the claim from the abandoned stream keeps
     * describing the one that's actually playing, which is how a reverted
     * FLAC swap leaves the "Lossless" badge lit over plain Opus.
     */
    fun clearDeclared(trackId: String?) {
        if (trackId != null) {
            declared.remove(trackId)
            sources.remove(trackId)
        }
    }

    /**
     * @param mediaId the queue's id for the track, which for a source-backed
     *   one wraps the source's id — unwrapped here so callers don't each have
     *   to know the key format.
     */
    fun declaredFormat(mediaId: String?): StreamFormat? {
        val key = mediaId ?: return null
        return declared[key]
            ?: SourceTrackKeys.parse(key)?.second?.let { declared[it] }
    }

    fun onTrackTransition() {
        current.value = null
    }

    /**
     * Drops everything measured about the last player, because there isn't one
     * any more.
     *
     * All of this describes a stream that a particular player was reading, and
     * it is scoped to the *process* while the player it describes is scoped to
     * [PlaybackService][com.music.bitchord.playback.PlaybackService] — which the
     * app being closed destroys while leaving the process alive to be reused.
     * Nothing else clears it: [current] is nulled when the queue moves on, and
     * a service standing back up is not the queue moving on.
     *
     * Measured, with the process surviving throughout — one log buffer holds
     * both halves:
     *
     * ```
     *   15:12:11  upgraded to FLAC at 4759ms      ← last session
     *   ——— app closed, service destroyed ———
     *   15:13:38  AdEKgwUqPKI <- audio/opus       ← played from the cache
     * ```
     *
     * Between those two lines the Now Playing screen read "Lossless" over a
     * player that had not been handed a single byte, and the nerd stats sheet
     * read `audio/opus · 160 kbps (source said: FLAC)` afterwards. Both are the
     * same fact: [Snapshot.isLossless] falls back to [Snapshot.claimed] while
     * the decoder has not spoken, and the claim came from a stream that had
     * stopped existing a minute earlier.
     *
     * @see com.music.bitchord.playback.QualityUpgrade.forgetLastSession for the
     *   half of this that decides whether the track gets its lossless copy back
     *   rather than merely how it is labelled.
     */
    fun forgetLastSession() {
        current.value = null
        racingLossless.value = emptySet()
        picked.clear()
        declared.clear()
        sources.clear()
    }

    private const val MAX_REMEMBERED = 64
}
