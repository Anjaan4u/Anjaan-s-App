package com.music.bitchord.data.stats

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import com.music.bitchord.data.model.Song
import com.music.bitchord.data.spotify.LocalPlaylistStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipInputStream

/**
 * Extra Backup: import playlists from JSON, M3U, or OpenTune `.backup` files.
 *
 * Only playlists and songs are imported — never app data or settings.
 * Everything lands in [LocalPlaylistStore] (on-device, no login needed).
 *
 * Format detection is by content, not extension:
 * - ZIP magic bytes → OpenTune `.backup` (reads `song.db` inside)
 * - `#EXTM3U` header → extended M3U
 * - otherwise → JSON
 */
object PlaylistImport {

    data class Summary(val playlists: Int, val songs: Int)

    /**
     * Imports playlists from [uri]. Returns a [Summary] on success.
     * Throws on failure with a human-readable message.
     */
    fun import(context: Context, uri: Uri): Summary {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            ?: throw IllegalArgumentException("Could not read file")
        if (bytes.isEmpty()) throw IllegalArgumentException("Empty file")

        val parsed: List<Pair<String, List<Song>>> = when {
            isZip(bytes) -> parseBackup(bytes)
            isM3u(bytes) -> parseM3u(bytes)
            else -> parseJson(bytes)
        }
        if (parsed.isEmpty()) throw IllegalArgumentException("No playlists found in file")

        var songCount = 0
        var playlistCount = 0
        for ((name, songs) in parsed) {
            if (songs.isEmpty()) continue
            // Dedupe by videoId within the playlist.
            val unique = songs.distinctBy { it.videoId }
            if (unique.isEmpty()) continue
            LocalPlaylistStore.savePlaylist(name.ifBlank { "Imported" }, unique)
            playlistCount++
            songCount += unique.size
        }
        if (playlistCount == 0) throw IllegalArgumentException("No songs found in file")
        return Summary(playlistCount, songCount)
    }

    private fun isZip(bytes: ByteArray): Boolean =
        bytes.size >= 4 &&
            bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte() &&
            bytes[2] == 0x03.toByte() && bytes[3] == 0x04.toByte()

    private fun isM3u(bytes: ByteArray): Boolean {
        val head = bytes.take(1024).toByteArray().toString(Charsets.UTF_8).trimStart()
        return head.startsWith("#EXTM3U")
    }

    // ------------------------------------------------------------------ JSON --

    /**
     * Accepts:
     * - `[{"name": "...", "songs": [{"videoId", "title", "artist", "thumbnailUrl"}]}]`
     * - `{"playlists": [...]}` wrapper
     * - BitChord export format (ignored: only playlists/songs are read)
     */
    private fun parseJson(bytes: ByteArray): List<Pair<String, List<Song>>> {
        val text = bytes.toString(Charsets.UTF_8).trim()
        if (text.isEmpty()) return emptyList()
        val out = ArrayList<Pair<String, List<Song>>>()

        fun songsFromArray(arr: JSONArray): List<Song> {
            val songs = ArrayList<Song>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val videoId = o.optString("videoId").ifBlank { o.optString("id") }
                if (videoId.isBlank()) continue
                songs += Song(
                    videoId = videoId,
                    title = o.optString("title").ifBlank { "Unknown" },
                    artist = o.optString("artist").ifBlank { o.optString("subtitle") },
                    thumbnailUrl = o.optString("thumbnailUrl").ifBlank { null },
                    durationText = o.optString("duration").ifBlank { null },
                )
            }
            return songs
        }

        if (text.startsWith("[")) {
            val arr = JSONArray(text)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val name = o.optString("name").ifBlank { o.optString("title") }
                val songsArr = o.optJSONArray("songs") ?: continue
                val songs = songsFromArray(songsArr)
                if (songs.isNotEmpty()) out += name to songs
            }
        } else {
            val obj = JSONObject(text)
            // {"playlists": [...]} wrapper
            val arr = obj.optJSONArray("playlists")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val name = o.optString("name").ifBlank { o.optString("title") }
                    val songsArr = o.optJSONArray("songs") ?: continue
                    val songs = songsFromArray(songsArr)
                    if (songs.isNotEmpty()) out += name to songs
                }
            }
        }
        return out
    }

    // ------------------------------------------------------------------- M3U --

    /**
     * Extended M3U. Track lines may be:
     * - `https://www.youtube.com/watch?v=<id>` or `https://youtu.be/<id>`
     * - a bare 11-char video id
     * Title/artist come from the preceding `#EXTINF` line when present.
     */
    private fun parseM3u(bytes: ByteArray): List<Pair<String, List<Song>>> {
        val lines = bytes.toString(Charsets.UTF_8).lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()
        val songs = ArrayList<Song>()
        var pendingTitle = ""
        var pendingArtist = ""
        for (line in lines) {
            if (line.startsWith("#EXTM3U")) continue
            if (line.startsWith("#EXTINF")) {
                // #EXTINF:<duration>,<artist> - <title>  (or just <title>)
                val comma = line.indexOf(',')
                if (comma >= 0) {
                    val info = line.substring(comma + 1).trim()
                    val dash = info.indexOf(" - ")
                    if (dash >= 0) {
                        pendingArtist = info.substring(0, dash).trim()
                        pendingTitle = info.substring(dash + 3).trim()
                    } else {
                        pendingTitle = info
                        pendingArtist = ""
                    }
                }
                continue
            }
            if (line.startsWith("#")) continue
            val videoId = extractVideoId(line) ?: continue
            songs += Song(
                videoId = videoId,
                title = pendingTitle.ifBlank { "Unknown" },
                artist = pendingArtist,
                thumbnailUrl = "https://i.ytimg.com/vi/$videoId/hqdefault.jpg",
            )
            pendingTitle = ""
            pendingArtist = ""
        }
        if (songs.isEmpty()) return emptyList()
        return listOf("Imported M3U" to songs)
    }

    private val YOUTUBE_URL_ID =
        Regex("""(?:youtube\.com/(?:watch\?.*v=|embed/|shorts/)|youtu\.be/)([A-Za-z0-9_-]{11})""")
    private val BARE_ID = Regex("""^[A-Za-z0-9_-]{11}$""")

    private fun extractVideoId(line: String): String? {
        YOUTUBE_URL_ID.find(line)?.let { return it.groupValues[1] }
        if (BARE_ID.matches(line)) return line
        // query param fallback: ?v=<id>
        val vParam = Regex("""[?&]v=([A-Za-z0-9_-]{11})""").find(line)
        if (vParam != null) return vParam.groupValues[1]
        return null
    }

    // ---------------------------------------------------------------- backup --

    /**
     * OpenTune `.backup`: a ZIP containing `song.db` (SQLite) plus `-wal`/`-shm`
     * sidecars. Reads `playlist`, `playlist_song_map`, `song`, `song_artist_map`,
     * `artist`.
     */
    private fun parseBackup(bytes: ByteArray): List<Pair<String, List<Song>>> {
        // Extract the db files to a temp dir.
        val tmpDir = File.createTempFile("opentune", "").let {
            it.delete()
            it.mkdirs()
            it
        }
        try {
            ZipInputStream(bytes.inputStream()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val out = File(tmpDir, File(entry.name).name)
                        out.outputStream().use { zip.copyTo(it) }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
            val dbFile = File(tmpDir, "song.db")
            if (!dbFile.isFile) throw IllegalArgumentException("No song.db in backup")
            return readSongDb(dbFile)
        } finally {
            tmpDir.deleteRecursively()
        }
    }

    private fun readSongDb(dbFile: File): List<Pair<String, List<Song>>> {
        val out = ArrayList<Pair<String, List<Song>>>()
        val db = SQLiteDatabase.openDatabase(
            dbFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY,
        )
        try {
            // playlistId -> (name)
            val playlists = ArrayList<Pair<String, String>>()
            db.rawQuery("SELECT id, name FROM playlist", null).use { c ->
                while (c.moveToNext()) {
                    playlists += c.getString(0) to c.getString(1)
                }
            }
            for ((playlistId, name) in playlists) {
                val songs = ArrayList<Song>()
                db.rawQuery(
                    """
                    SELECT s.id, s.title, s.thumbnailUrl,
                           GROUP_CONCAT(a.name, ', ')
                    FROM playlist_song_map m
                    JOIN song s ON s.id = m.songId
                    LEFT JOIN song_artist_map sam ON sam.songId = s.id
                    LEFT JOIN artist a ON a.id = sam.artistId
                    WHERE m.playlistId = ?
                    GROUP BY s.id
                    ORDER BY m.position
                    """.trimIndent(),
                    arrayOf(playlistId),
                ).use { c ->
                    while (c.moveToNext()) {
                        val videoId = c.getString(0) ?: continue
                        if (videoId.isBlank()) continue
                        songs += Song(
                            videoId = videoId,
                            title = c.getString(1) ?: "Unknown",
                            artist = c.getString(3) ?: "",
                            thumbnailUrl = c.getString(2),
                        )
                    }
                }
                if (songs.isNotEmpty()) out += name to songs
            }
        } finally {
            db.close()
        }
        return out
    }
}
