package com.music.bitchord.data.spotify

import android.content.Context
import android.content.SharedPreferences
import com.music.bitchord.data.model.Song
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * Local listening history for guests (no YouTube Music login).
 *
 * The account history path ([YtMusicRepository.history]) needs a signed-in
 * session, so guests saw "sign in required" and no history at all. This store
 * records every played song on-device in SharedPreferences, most recent first,
 * so the History screen works without an account. Signed-in users keep using
 * YouTube's history; this store is only consulted when there is no session.
 */
object LocalHistoryStore {
    private const val PREF_NAME = "bitchord_local_history"
    private const val KEY_HISTORY = "history_json"

    /** How many recent plays are kept; older ones fall off the end. */
    private const val MAX_ENTRIES = 200

    private lateinit var prefs: SharedPreferences

    private val _history = MutableStateFlow<List<Song>>(emptyList())
    val history = _history.asStateFlow()

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        load()
    }

    private fun load() {
        if (!this::prefs.isInitialized) return
        val raw = prefs.getString(KEY_HISTORY, null) ?: return
        runCatching {
            val songs = mutableListOf<Song>()
            val jsonArray = JSONArray(raw)
            for (i in 0 until jsonArray.length()) {
                val sObj = jsonArray.getJSONObject(i)
                songs.add(
                    Song(
                        videoId = sObj.optString("videoId", ""),
                        title = sObj.optString("title", ""),
                        artist = sObj.optString("artist", ""),
                        thumbnailUrl = sObj.optString("thumbnailUrl", null)
                            .takeIf { !it.isNullOrBlank() && it != "null" },
                        durationText = sObj.optString("durationText", null)
                            .takeIf { !it.isNullOrBlank() && it != "null" },
                        artistId = sObj.optString("artistId", null)
                            .takeIf { !it.isNullOrBlank() && it != "null" },
                        albumId = sObj.optString("albumId", null)
                            .takeIf { !it.isNullOrBlank() && it != "null" },
                        albumName = sObj.optString("albumName", null)
                            .takeIf { !it.isNullOrBlank() && it != "null" },
                        isVideo = sObj.optBoolean("isVideo", false),
                    ),
                )
            }
            _history.value = songs
        }
    }

    /**
     * Records a play: moves the song to the front (deduplicated by videoId),
     * trimming the tail to [MAX_ENTRIES]. Never throws.
     */
    fun recordPlay(song: Song) {
        if (!this::prefs.isInitialized) return
        if (song.videoId.isBlank()) return
        runCatching {
            val updated = _history.value
                .filterNot { it.videoId == song.videoId }
                .toMutableList()
                .apply { add(0, song) }
                .take(MAX_ENTRIES)
            _history.value = updated
            persist(updated)
        }
    }

    /** Clears the local history. Never throws. */
    fun clear() {
        if (!this::prefs.isInitialized) return
        runCatching {
            _history.value = emptyList()
            prefs.edit().remove(KEY_HISTORY).apply()
        }
    }

    private fun persist(songs: List<Song>) {
        runCatching {
            val jsonArray = JSONArray()
            for (song in songs) {
                val sObj = JSONObject()
                sObj.put("videoId", song.videoId)
                sObj.put("title", song.title)
                sObj.put("artist", song.artist)
                sObj.put("thumbnailUrl", song.thumbnailUrl)
                sObj.put("durationText", song.durationText)
                sObj.put("artistId", song.artistId)
                sObj.put("albumId", song.albumId)
                sObj.put("albumName", song.albumName)
                sObj.put("isVideo", song.isVideo)
                jsonArray.put(sObj)
            }
            prefs.edit().putString(KEY_HISTORY, jsonArray.toString()).apply()
        }
    }
}
