package com.music.bitchord.data.lyrics

import android.content.Context
import java.io.File
import java.security.MessageDigest
import java.util.Locale

/**
 * Offline lyrics sidecars for cached songs.
 *
 * When a streamed song's lyrics are fetched, a plain LRC copy is filed here
 * next to the cached audio so the player keeps its synced lyrics with no
 * network at all — after "Clear cache", in airplane mode, anywhere.
 *
 * Storage is the app-data directory ([Context.getFilesDir]), never the cache
 * directory: the system's "Clear cache" button and phone-cleaner apps wipe
 * the latter, while this survives everything short of "Clear data" or an
 * uninstall.
 *
 * The copy is line-level only — [LyricLine.words] syllable timing does not
 * round-trip through LRC. The player already renders line-synced lyrics (the
 * LrcLib/Musixmatch/KuGou path), so the offline copy degrades gracefully
 * rather than failing.
 *
 * Reads never throw; a corrupt sidecar reads as "no lyrics", and the normal
 * network lookup runs instead.
 */
object OfflineLyrics {

    private const val DIR_NAME = "lyrics"

    private fun dir(context: Context): File =
        File(context.filesDir, DIR_NAME).apply { mkdirs() }

    private fun fileFor(context: Context, videoId: String): File =
        File(dir(context), "${sha1(videoId)}.lrc")

    /**
     * The offline copy for [videoId], or null when there is none (or it does
     * not parse). Callers fall back to the network lookup.
     */
    fun read(context: Context, videoId: String): List<LyricLine>? {
        if (videoId.isBlank()) return null
        val file = fileFor(context, videoId)
        if (!file.isFile || file.length() == 0L) return null
        return runCatching { parse(file.readText()) }.getOrNull()
            ?.takeIf { it.isNotEmpty() }
    }

    /**
     * Files [lines] for [videoId], replacing any previous copy. Never throws.
     * Word-level timing is intentionally dropped — see the class doc.
     */
    fun write(context: Context, videoId: String, lines: List<LyricLine>) {
        if (videoId.isBlank() || lines.isEmpty()) return
        runCatching {
            val file = fileFor(context, videoId)
            val tmp = File(file.parent, "${file.name}.tmp")
            tmp.writeText(serialize(lines))
            // Atomic-ish: readers never see a half-written sidecar.
            if (!tmp.renameTo(file)) {
                file.delete()
                tmp.renameTo(file)
            }
        }
    }

    /** Drops the offline copy for [videoId]. Never throws. */
    fun delete(context: Context, videoId: String) {
        if (videoId.isBlank()) return
        runCatching { fileFor(context, videoId).delete() }
    }

    /** Drops every offline copy. Used by "Clear song cache". Never throws. */
    fun clearAll(context: Context) {
        runCatching { dir(context).deleteRecursively() }
    }

    private fun serialize(lines: List<LyricLine>): String = buildString {
        for (line in lines) {
            val ms = line.timeMs.coerceAtLeast(0L)
            val mm = ms / 60000
            val ss = (ms % 60000) / 1000
            val cs = (ms % 1000) / 10
            val text = line.text.replace('\n', ' ').replace('\r', ' ')
            append(String.format(Locale.ROOT, "[%02d:%02d.%02d]%s\n", mm, ss, cs, text))
        }
    }

    private val LRC_LINE =
        Regex("""\[(\d+):(\d+)(?:[.:](\d{1,3}))?](.*)""")

    private fun parse(lrc: String): List<LyricLine> {
        val out = ArrayList<LyricLine>(lrc.length / 32)
        for (raw in lrc.lineSequence()) {
            val m = LRC_LINE.matchEntire(raw.trim()) ?: continue
            val mm = m.groupValues[1].toLongOrNull() ?: continue
            val ss = m.groupValues[2].toLongOrNull() ?: continue
            val frac = m.groupValues[3]
            val fracMs = when {
                frac.isEmpty() -> 0L
                frac.length == 1 -> frac.toLongOrNull()?.times(100) ?: 0L
                frac.length == 2 -> frac.toLongOrNull()?.times(10) ?: 0L
                else -> frac.take(3).toLongOrNull() ?: 0L
            }
            out += LyricLine(
                timeMs = mm * 60000 + ss * 1000 + fracMs,
                text = m.groupValues[4].trimEnd(),
            )
        }
        return out.sortedBy { it.timeMs }
    }

    private fun sha1(s: String): String {
        val bytes = MessageDigest.getInstance("SHA-1")
            .digest(s.toByteArray(Charsets.UTF_8))
        return buildString(bytes.size * 2) {
            for (b in bytes) append(String.format(Locale.ROOT, "%02x", b))
        }
    }
}
