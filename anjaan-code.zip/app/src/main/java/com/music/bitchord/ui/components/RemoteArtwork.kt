package com.music.bitchord.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.music.bitchord.data.model.Song
import com.music.bitchord.data.remote.OfflineArtwork
import com.music.bitchord.data.remote.RemoteArtworkStore
import com.music.bitchord.data.sources.SourceRegistry
import com.music.bitchord.data.model.isUsableArtworkUrl

/**
 * A drawable art URL for [song]: its own thumbnail when it has one, else the
 * embedded picture pulled out of the remote file and cached — else null.
 *
 * A cover filed offline next to the cached audio ([OfflineArtwork]) wins over
 * the network URL: after "Clear cache" wipes Coil's disk cache — or with no
 * connection at all — the player keeps its artwork with no glitch.
 *
 * The extraction only ever runs for remote-library tracks with no thumbnail;
 * every other row resolves synchronously to what it already had, so this is
 * safe to call from shared components like [SongRow] that draw every library
 * in the app. Keyed on the track id, so a recycled row re-resolves instead
 * of flashing a stranger's cover.
 */
@Composable
fun rememberRemoteArtworkUrl(song: Song?): String? {
    val context = LocalContext.current
    val key = song?.videoId
    var resolved by remember(key) {
        mutableStateOf(
            song?.videoId?.let { OfflineArtwork.localUriFor(context, it) }
                ?: song?.thumbnailUrl?.takeIf { isUsableArtworkUrl(it) },
        )
    }
    LaunchedEffect(key) {
        // Anjaan thumbnail fallback: the main player and the mini player can
        // receive different Song copies for the same track, and the main
        // player's copy sometimes arrives with a null thumbnail while the mini
        // player's has it. For plain YouTube tracks the standard thumbnail URL
        // is rebuilt from the video id, so the main player shows the same cover
        // the mini player does instead of a placeholder. Offline cached art and
        // real thumbnails are never overridden; quality/size are untouched —
        // callers still apply their own artworkAt sizing.
        if (song != null && resolved == null) {
            resolved = when {
                song.videoId.startsWith("webdav:") || song.videoId.startsWith("smb:") ->
                    RemoteArtworkStore.resolveArt(context, song)
                SourceRegistry.parseTrackKey(song.videoId) == null &&
                    !song.videoId.contains(":") ->
                    "https://i.ytimg.com/vi/${song.videoId}/hqdefault.jpg"
                else -> null
            }
        }
    }
    return resolved
}
