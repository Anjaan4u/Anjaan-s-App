package com.music.bitchord.data.stats

import com.music.bitchord.data.model.Song

/**
 * Playlist export: turns a playlist's songs into a shareable file or text.
 *
 * - M3U: extended M3U with `#EXTINF` title/artist lines and YouTube URLs —
 *   re-importable via Extra Backup.
 * - CSV: title, artist, video id, and URL columns.
 * - Share text: numbered song list with YouTube links, for messaging apps.
 */
object PlaylistExport {

    enum class Format(val extension: String, val mime: String) {
        M3U("m3u", "audio/x-mpegurl"),
        CSV("csv", "text/csv"),
    }

    fun fileName(playlistName: String, format: Format): String {
        val safe = playlistName.trim().ifBlank { "playlist" }
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
            .take(80)
        return "$safe.${format.extension}"
    }

    fun toM3u(playlistName: String, songs: List<Song>): String {
        val sb = StringBuilder("#EXTM3U\n")
        sb.append("#PLAYLIST:").append(playlistName.trim()).append('\n')
        for (song in songs) {
            val info = if (song.artist.isNotBlank()) "${song.artist} - ${song.title}" else song.title
            sb.append("#EXTINF:-1,").append(info).append('\n')
            sb.append("https://www.youtube.com/watch?v=").append(song.videoId).append('\n')
        }
        return sb.toString()
    }

    fun toCsv(songs: List<Song>): String {
        val sb = StringBuilder("Title,Artist,VideoId,Url\n")
        for (song in songs) {
            sb.append(csvField(song.title)).append(',')
                .append(csvField(song.artist)).append(',')
                .append(csvField(song.videoId)).append(',')
                .append(csvField("https://www.youtube.com/watch?v=${song.videoId}"))
                .append('\n')
        }
        return sb.toString()
    }

    private fun csvField(s: String): String {
        val escaped = s.replace("\"", "\"\"")
        return if (s.contains(',') || s.contains('"') || s.contains('\n')) "\"$escaped\"" else escaped
    }

    /** Shareable text: the playlist as a numbered list with YouTube links. */
    fun shareText(playlistName: String, songs: List<Song>): String {
        val sb = StringBuilder("\uD83C\uDFB5 $playlistName\n")
        for ((i, song) in songs.withIndex()) {
            val info = if (song.artist.isNotBlank()) "${song.title} - ${song.artist}" else song.title
            sb.append("\n${i + 1}. $info\n")
            sb.append("https://www.youtube.com/watch?v=${song.videoId}\n")
        }
        return sb.toString()
    }
}
