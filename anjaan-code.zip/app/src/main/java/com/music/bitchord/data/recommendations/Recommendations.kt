package com.music.bitchord.data.recommendations

import com.music.bitchord.data.model.HomeShelf
import com.music.bitchord.data.model.ShelfItem
import com.music.bitchord.data.scrobbling.LastFM
import com.music.bitchord.data.sources.SourceRegistry
import com.music.bitchord.data.stats.ListeningStats
import com.music.bitchord.data.stats.ReplayPeriod
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext

/**
 * Personalized song recommendations based on the listener's own history.
 *
 * Each device builds its own list from its local [ListeningStats]: the top
 * artists come from what was actually played here, similar artists come from
 * Last.fm (no login needed — the app's API key is enough), and songs are
 * resolved through the normal search pipeline. No hardcoding, no server.
 */
object Recommendations {

    private const val TOP_ARTISTS = 3
    private const val SIMILAR_PER_ARTIST = 2
    private const val SONGS_PER_ARTIST = 3
    private const val MAX_SONGS = 15

    /**
     * Builds the "Recommended for you" shelf, or null when there is not
     * enough listening history (or every lookup failed).
     */
    suspend fun buildShelf(): HomeShelf? = withContext(Dispatchers.IO) {
        val topArtists = topArtists() 
        if (topArtists.isEmpty()) return@withContext null

        // Mix: songs by the artists themselves + songs by similar artists.
        val songs = coroutineScope {
            val jobs = mutableListOf<kotlinx.coroutines.Deferred<List<ShelfItem>>>()

            // Same artists the listener already plays.
            topArtists.forEach { artist ->
                jobs += async { songsByArtist(artist, SONGS_PER_ARTIST) }
            }

            // Similar artists for discovery.
            topArtists.forEach { artist ->
                val similar = LastFM.getSimilarArtists(artist, SIMILAR_PER_ARTIST)
                similar.forEach { similarArtist ->
                    // Skip if it's one of the top artists already.
                    if (similarArtist !in topArtists) {
                        jobs += async { songsByArtist(similarArtist, 2) }
                    }
                }
            }

            jobs.awaitAll().flatten()
        }

        // Deduplicate by videoId, keep order (same-artist songs first).
        val seen = mutableSetOf<String>()
        val unique = songs.filter { item ->
            val id = item.videoId ?: return@filter false
            seen.add(id)
        }.take(MAX_SONGS)

        if (unique.isEmpty()) return@withContext null

        HomeShelf(
            title = "Recommended for you",
            subtitle = "Based on your recent listening",
            items = unique,
        )
    }

    /** Top artist names from this device's listening history. */
    private suspend fun topArtists(): List<String> =
        runCatching {
            // Prefer this year's taste; fall back to all time.
            val summary = ListeningStats.summary(ReplayPeriod.THIS_YEAR)
            val artists = summary.artists.take(TOP_ARTISTS).map { it.title }
            if (artists.isNotEmpty()) return artists
            ListeningStats.summary(ReplayPeriod.ALL_TIME)
                .artists.take(TOP_ARTISTS).map { it.title }
        }.getOrDefault(emptyList())
            .map { it.trim() }
            .filter { it.isNotBlank() }
            .distinct()
            .take(TOP_ARTISTS)

    /** Searches for songs by [artistName] and maps them to shelf items. */
    private suspend fun songsByArtist(artistName: String, limit: Int): List<ShelfItem> =
        runCatching {
            val sources = SourceRegistry.active()
                .filter { it.kind != com.music.bitchord.data.sources.SourceKind.YOUTUBE }
            val songs = sources.firstOrNull()?.search(
                query = artistName,
                limit = limit * 2, // Over-fetch; filter to the artist below.
            ).orEmpty()
            songs
                .filter { song ->
                    // Keep only songs actually by this artist (search is fuzzy).
                    song.artist.contains(artistName, ignoreCase = true) ||
                        artistName.contains(song.artist, ignoreCase = true)
                }
                .take(limit)
                .map { song ->
                    ShelfItem(
                        title = song.title,
                        subtitle = song.artist,
                        thumbnailUrl = song.thumbnailUrl,
                        videoId = song.videoId,
                        browseId = null,
                    )
                }
        }.getOrDefault(emptyList())
}
