package com.music.bitchord.data

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * In-app launcher icon selector.
 *
 * Uses one <activity-alias> per icon in the manifest. Switching is two-phase:
 * 1. Enable the new alias immediately (never leave zero enabled launchers).
 * 2. Disable the old aliases in MainActivity.onStop() — disabling the alias
 *    the current task runs under kills the task even with DONT_KILL_APP.
 *
 * The choice is persisted and re-asserted on startup so it survives reboots.
 */
object AppIconSwitcher {

    data class IconOption(
        val aliasClassName: String,
        val title: String,
        /** Mipmap resource name for preview (without @mipmap/ prefix). */
        val mipmapName: String,
    )

    val ICONS = listOf(
        IconOption("IconDefault", "Stairs", "ic_launcher"),
        IconOption("IconSunflower", "Sunflower", "ic_launcher_sunflower"),
        IconOption("IconSunset", "Sunset", "ic_launcher_sunset"),
    )

    private const val PREFS = "app_icons"
    private const val PREF_KEY = "selected_icon_alias"

    private var pendingDisable: List<String>? = null

    /** Full component name: package + alias class. */
    private fun fullName(context: Context, alias: String) = "${context.packageName}.$alias"

    /** Currently enabled alias, or null if none (should not happen). */
    fun currentAlias(context: Context): String? {
        val pm = context.packageManager
        return ICONS.firstOrNull { opt ->
            try {
                val state = pm.getComponentEnabledSetting(ComponentName(context, fullName(context, opt.aliasClassName)))
                state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED ||
                    (state == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT && opt.aliasClassName == "IconDefault")
            } catch (e: Exception) {
                false
            }
        }?.aliasClassName
    }

    /**
     * Switch icon immediately (Archive Tune pattern):
     * 1. Enable the new alias.
     * 2. Disable old aliases immediately.
     * The app task will close (expected — not a crash), and the launcher
     * shows the new icon. User reopens from the new icon.
     */
    fun selectIcon(context: Context, aliasClassName: String) {
        // Save to prefs FIRST (so UI persists even if PM fails)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(PREF_KEY, aliasClassName).apply()
        if (currentAlias(context) == aliasClassName) return
        val pm = context.packageManager
        // DEBUG: Show errors in Toast instead of silently ignoring
        try {
            // Phase 1: enable new first (never zero launchers).
            setEnabled(pm, context, fullName(context, aliasClassName), PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
            android.widget.Toast.makeText(context, "Enabled: $aliasClassName", android.widget.Toast.LENGTH_SHORT).show()
            // Phase 2: disable others immediately.
            for (opt in ICONS) {
                if (opt.aliasClassName != aliasClassName) {
                    setEnabled(pm, context, fullName(context, opt.aliasClassName), PackageManager.COMPONENT_ENABLED_STATE_DISABLED)
                }
            }
            android.widget.Toast.makeText(context, "Disabled others", android.widget.Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            android.widget.Toast.makeText(context, "ERROR: ${e.javaClass.simpleName}: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        pendingDisable = null
    }

    /**
     * No-op now (immediate switch). Kept for MainActivity.onStop compatibility.
     */
    fun flushPendingCleanup(context: Context) {
        // Immediate mode: nothing pending.
    }

    /** Re-assert the persisted choice on cold start (survives reboot). */
    fun reassertOnStartup(context: Context) {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(PREF_KEY, null) ?: return
        val pm = context.packageManager
        try {
            if (pm.getComponentEnabledSetting(ComponentName(context, fullName(context, saved))) !=
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
                setEnabled(pm, context, fullName(context, saved), PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
                pendingDisable = ICONS.map { it.aliasClassName }.filter { it != saved }
                flushPendingCleanup(context)
            }
        } catch (e: Exception) {
            // Ignore — alias may not exist on this build.
        }
    }

    private fun setEnabled(pm: PackageManager, context: Context, alias: String, state: Int) {
        // Don't use DONT_KILL_APP — let the system close the app naturally
        // (like Archive Tune). The launcher updates and user reopens from new icon.
        pm.setComponentEnabledSetting(
            ComponentName(context, alias),
            state,
            0,
        )
    }
}
