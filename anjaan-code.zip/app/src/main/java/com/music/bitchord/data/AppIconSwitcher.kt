package com.music.bitchord.data

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.app.Activity
import android.content.ContextWrapper
import android.os.Build
import com.music.bitchord.R

/**
 * In-app launcher icon selector.
 *
 * Uses one <activity-alias> per icon in the manifest. Switching is three-phase:
 * 1. Enable the new alias immediately (never leave zero enabled launchers).
 * 2. Disable the other aliases, skipping the one the app is running under.
 * 3. Disable the previous alias LAST — disabling the alias the current task
 *    runs under kills the process, so it must be the final PM call, otherwise
 *    the remaining disables never run and the launcher shows duplicate icons.
 *
 * The choice is persisted and re-asserted on startup so it survives reboots;
 * startup also self-heals duplicates left by older builds.
 */
object AppIconSwitcher {

    data class IconOption(
        val aliasClassName: String,
        val title: String,
        /** Mipmap resource name for preview (without @mipmap/ prefix). */
        val mipmapName: String,
    )

    val ICONS = listOf(
        IconOption("IconDefault", "Stairs", "ic_launcher"),
        IconOption("IconSunflower", "Sunflower", "ic_launcher_sunflower"),
        IconOption("IconSunset", "Sunset", "ic_launcher_sunset"),
        IconOption("IconCats", "Cats", "ic_launcher_cats"),
        IconOption("IconRadhaKrishna", "Radha Krishna", "ic_launcher_radhakrishna"),
        IconOption("IconKrishna", "Krishna", "ic_launcher_krishna"),
    )

    private const val PREFS = "app_icons"
    private const val PREF_KEY = "selected_icon_alias"

    private var pendingDisable: List<String>? = null

    /** Full component name: namespace + alias class. */
    // NOTE: Manifest aliases resolve against `namespace` (com.music.bitchord),
    // NOT applicationId! So we hardcode the namespace here.
    private fun fullName(context: Context, alias: String) = "com.music.bitchord.$alias"

    /** Saved icon alias from prefs, or null if never picked. */
    fun savedAlias(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(PREF_KEY, null)

    /** Currently enabled alias, or null if none (should not happen). */
    fun currentAlias(context: Context): String? {
        val pm = context.packageManager
        return ICONS.firstOrNull { opt ->
            try {
                val state = pm.getComponentEnabledSetting(ComponentName(context, fullName(context, opt.aliasClassName)))
                state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED ||
                    (state == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT && opt.aliasClassName == "IconDefault")
            } catch (e: Exception) {
                false
            }
        }?.aliasClassName
    }

    /**
     * Switch icon immediately (Archive Tune pattern):
     * 1. Enable the new alias.
     * 2. Disable old aliases immediately.
     * The app task will close (expected — not a crash), and the launcher
     * shows the new icon. User reopens from the new icon.
     */
    fun selectIcon(context: Context, aliasClassName: String) {
        val pm = context.packageManager
        // Save to prefs FIRST (so UI persists even if PM fails)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(PREF_KEY, aliasClassName).commit()
        // Persist the splash theme for the next launch (API 31+).
        persistSplashTheme(context, aliasClassName)
        try {
            // Enable new first (never zero launchers), then disable others.
            // DONT_KILL_APP: the process survives, so no crash feeling and
            // the loop always completes (no duplicate-icon race).
            setEnabled(pm, context, fullName(context, aliasClassName),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
            for (opt in ICONS) {
                if (opt.aliasClassName != aliasClassName) {
                    try {
                        setEnabled(pm, context, fullName(context, opt.aliasClassName),
                            PackageManager.COMPONENT_ENABLED_STATE_DISABLED)
                    } catch (e: Exception) {
                        // Keep disabling the rest.
                    }
                }
            }
        } catch (e: Exception) {
            return
        }
        // Soft-verify: log if the switch didn't apply cleanly (don't crash UI).
        if (!isSingleAliasEnabled(context, aliasClassName)) {
            android.util.Log.w("AppIconSwitcher", "Icon switch may not have applied cleanly for $aliasClassName")
        }
        pendingDisable = null
    }

    /** True when exactly the expected alias is enabled. */
    private fun isSingleAliasEnabled(context: Context, expected: String): Boolean {
        val pm = context.packageManager
        var enabledCount = 0
        var expectedEnabled = false
        for (opt in ICONS) {
            val state = pm.getComponentEnabledSetting(
                ComponentName(context, fullName(context, opt.aliasClassName)))
            // COMPONENT_ENABLED_STATE_DEFAULT falls back to manifest (only
            // IconDefault is enabled="true" there).
            val isEnabled = when (state) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED -> true
                PackageManager.COMPONENT_ENABLED_STATE_DEFAULT ->
                    opt.aliasClassName == "IconDefault"
                else -> false
            }
            if (isEnabled) {
                enabledCount++
                if (opt.aliasClassName == expected) expectedEnabled = true
            }
        }
        return enabledCount == 1 && expectedEnabled
    }

    /**
     * No-op now (immediate switch). Kept for MainActivity.onStop compatibility.
     */
    fun flushPendingCleanup(context: Context) {
        // Immediate mode: nothing pending.
    }

    /** Re-assert the persisted choice on cold start (survives reboot). */
    fun reassertOnStartup(context: Context) {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(PREF_KEY, null) ?: return
        val pm = context.packageManager
        try {
            if (pm.getComponentEnabledSetting(ComponentName(context, fullName(context, saved))) !=
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
                setEnabled(pm, context, fullName(context, saved), PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
            }
            // Self-heal: disable any other enabled aliases. Safe here because
            // we're running under `saved`, so none of these kills our process.
            // This cleans up duplicate icons left by older builds.
            for (opt in ICONS) {
                if (opt.aliasClassName != saved) {
                    try {
                        setEnabled(pm, context, fullName(context, opt.aliasClassName), PackageManager.COMPONENT_ENABLED_STATE_DISABLED)
                    } catch (e: Exception) {
                        // Ignore.
                    }
                }
            }
        } catch (e: Exception) {
            // Ignore — alias may not exist on this build.
        }
        pendingDisable = null
    }

    /** Splash theme matching each icon alias, for the system splash. */
    fun splashThemeFor(alias: String): Int = when (alias) {
        "IconSunflower" -> R.style.Theme_BitChord_Splash_Sunflower
        "IconSunset" -> R.style.Theme_BitChord_Splash_Sunset
        "IconCats" -> R.style.Theme_BitChord_Splash_Cats
        "IconRadhaKrishna" -> R.style.Theme_BitChord_Splash_RadhaKrishna
        "IconKrishna" -> R.style.Theme_BitChord_Splash_Krishna
        else -> R.style.Theme_BitChord_Splash_Default
    }

    /**
     * Persist the matching splash theme for the next launch (API 31+).
     * Uses Activity.splashScreen.setSplashScreenTheme() (instance method) —
     * the system stores it per package, so the correct icon is drawn even
     * though the alias's manifest theme is ignored for the splash.
     */
    fun persistSplashTheme(context: Context, alias: String) {
        if (Build.VERSION.SDK_INT < 31) return
        try {
            val activity = context.asActivity() ?: return
            activity.splashScreen.setSplashScreenTheme(splashThemeFor(alias))
        } catch (e: Exception) {
            // Best effort — splash just shows the default icon.
        }
    }

    /** Unwrap a Context to its Activity, or null. */
    private fun Context.asActivity(): Activity? {
        var ctx: Context = this
        while (ctx is ContextWrapper) {
            if (ctx is Activity) return ctx
            ctx = ctx.baseContext
        }
        return null
    }

    private fun setEnabled(pm: PackageManager, context: Context, alias: String, state: Int) {
        // DONT_KILL_APP: the app survives the switch (like ArchiveTune) —
        // no crash feeling, no restart needed, home-screen shortcut kept.
        pm.setComponentEnabledSetting(
            ComponentName(context, alias),
            state,
            PackageManager.DONT_KILL_APP,
        )
    }
}
