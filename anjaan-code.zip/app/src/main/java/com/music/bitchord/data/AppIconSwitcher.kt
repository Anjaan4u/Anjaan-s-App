package com.music.bitchord.data

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * In-app launcher icon selector.
 *
 * Uses one <activity-alias> per icon in the manifest. Switching is three-phase:
 * 1. Enable the new alias immediately (never leave zero enabled launchers).
 * 2. Disable the other aliases, skipping the one the app is running under.
 * 3. Disable the previous alias LAST — disabling the alias the current task
 *    runs under kills the process, so it must be the final PM call, otherwise
 *    the remaining disables never run and the launcher shows duplicate icons.
 *
 * The choice is persisted and re-asserted on startup so it survives reboots;
 * startup also self-heals duplicates left by older builds.
 */
object AppIconSwitcher {

    data class IconOption(
        val aliasClassName: String,
        val title: String,
        /** Mipmap resource name for preview (without @mipmap/ prefix). */
        val mipmapName: String,
    )

    val ICONS = listOf(
        IconOption("IconDefault", "Stairs", "ic_launcher"),
        IconOption("IconSunflower", "Sunflower", "ic_launcher_sunflower"),
        IconOption("IconSunset", "Sunset", "ic_launcher_sunset"),
        IconOption("IconCats", "Cats", "ic_launcher_cats"),
        IconOption("IconRadhaKrishna", "Radha Krishna", "ic_launcher_radhakrishna"),
        IconOption("IconKrishna", "Krishna", "ic_launcher_krishna"),
    )

    private const val PREFS = "app_icons"
    private const val PREF_KEY = "selected_icon_alias"

    private var pendingDisable: List<String>? = null

    /** Full component name: namespace + alias class. */
    // NOTE: Manifest aliases resolve against `namespace` (com.music.bitchord),
    // NOT applicationId! So we hardcode the namespace here.
    private fun fullName(context: Context, alias: String) = "com.music.bitchord.$alias"

    /** Currently enabled alias, or null if none (should not happen). */
    fun currentAlias(context: Context): String? {
        val pm = context.packageManager
        return ICONS.firstOrNull { opt ->
            try {
                val state = pm.getComponentEnabledSetting(ComponentName(context, fullName(context, opt.aliasClassName)))
                state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED ||
                    (state == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT && opt.aliasClassName == "IconDefault")
            } catch (e: Exception) {
                false
            }
        }?.aliasClassName
    }

    /**
     * Switch icon immediately (Archive Tune pattern):
     * 1. Enable the new alias.
     * 2. Disable old aliases immediately.
     * The app task will close (expected — not a crash), and the launcher
     * shows the new icon. User reopens from the new icon.
     */
    fun selectIcon(context: Context, aliasClassName: String) {
        val pm = context.packageManager
        // Which alias is the app running under right now? Disabling it kills
        // our process, so it must be disabled LAST — otherwise the remaining
        // disables never run and the launcher keeps showing multiple icons.
        val previous = currentAlias(context)
        // Save to prefs FIRST (so UI persists even if PM fails)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(PREF_KEY, aliasClassName).commit()
        // Always do the PM work (no early return — avoids "2 tries" issue)
        try {
            // Phase 1: enable new first (never zero launchers).
            setEnabled(pm, context, fullName(context, aliasClassName), PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
            // Phase 2: disable the others, skipping the one we're running under.
            for (opt in ICONS) {
                if (opt.aliasClassName != aliasClassName && opt.aliasClassName != previous) {
                    try {
                        setEnabled(pm, context, fullName(context, opt.aliasClassName), PackageManager.COMPONENT_ENABLED_STATE_DISABLED)
                    } catch (e: Exception) {
                        // Keep disabling the rest.
                    }
                }
            }
            // Phase 3: disable the previous alias LAST (this closes the app — expected).
            if (previous != null && previous != aliasClassName) {
                setEnabled(pm, context, fullName(context, previous), PackageManager.COMPONENT_ENABLED_STATE_DISABLED)
            }
        } catch (e: Exception) {
            return
        }
        pendingDisable = null
    }

    /**
     * No-op now (immediate switch). Kept for MainActivity.onStop compatibility.
     */
    fun flushPendingCleanup(context: Context) {
        // Immediate mode: nothing pending.
    }

    /** Re-assert the persisted choice on cold start (survives reboot). */
    fun reassertOnStartup(context: Context) {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(PREF_KEY, null) ?: return
        val pm = context.packageManager
        try {
            if (pm.getComponentEnabledSetting(ComponentName(context, fullName(context, saved))) !=
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
                setEnabled(pm, context, fullName(context, saved), PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
            }
            // Self-heal: disable any other enabled aliases. Safe here because
            // we're running under `saved`, so none of these kills our process.
            // This cleans up duplicate icons left by older builds.
            for (opt in ICONS) {
                if (opt.aliasClassName != saved) {
                    try {
                        setEnabled(pm, context, fullName(context, opt.aliasClassName), PackageManager.COMPONENT_ENABLED_STATE_DISABLED)
                    } catch (e: Exception) {
                        // Ignore.
                    }
                }
            }
        } catch (e: Exception) {
            // Ignore — alias may not exist on this build.
        }
        pendingDisable = null
    }

    private fun setEnabled(pm: PackageManager, context: Context, alias: String, state: Int) {
        // Don't use DONT_KILL_APP — let the system close the app naturally
        // (like Archive Tune). The launcher updates and user reopens from new icon.
        pm.setComponentEnabledSetting(
            ComponentName(context, alias),
            state,
            0,
        )
    }
}
