package com.music.bitchord.data

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * In-app launcher icon selector.
 *
 * Uses one <activity-alias> per icon in the manifest. Switching is two-phase:
 * 1. Enable the new alias immediately (never leave zero enabled launchers).
 * 2. Disable the old aliases in MainActivity.onStop() — disabling the alias
 *    the current task runs under kills the task even with DONT_KILL_APP.
 *
 * The choice is persisted and re-asserted on startup so it survives reboots.
 */
object AppIconSwitcher {

    data class IconOption(
        val aliasClassName: String,
        val title: String,
        /** Mipmap resource name for preview (without @mipmap/ prefix). */
        val mipmapName: String,
    )

    val ICONS = listOf(
        IconOption("IconDefault", "Stairs", "ic_launcher"),
        IconOption("IconSunflower", "Sunflower", "ic_launcher_sunflower"),
        IconOption("IconSunset", "Sunset", "ic_launcher_sunset"),
        IconOption("IconStairs2", "Stairs 2", "ic_launcher_stairs2"),
    )

    private const val PREFS = "app_icons"
    private const val PREF_KEY = "selected_icon_alias"

    private var pendingDisable: List<String>? = null

    /** Full component name: package + alias class. */
    private fun fullName(context: Context, alias: String) = "${context.packageName}.$alias"

    /** Currently enabled alias, or null if none (should not happen). */
    fun currentAlias(context: Context): String? {
        val pm = context.packageManager
        return ICONS.firstOrNull { opt ->
            try {
                val state = pm.getComponentEnabledSetting(ComponentName(context, fullName(context, opt.aliasClassName)))
                state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED ||
                    (state == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT && opt.aliasClassName == "IconDefault")
            } catch (e: Exception) {
                false
            }
        }?.aliasClassName
    }

    /**
     * Phase 1: enable the new alias immediately. Safe to call from UI thread.
     * The old aliases are disabled later in [flushPendingCleanup].
     */
    fun selectIcon(context: Context, aliasClassName: String) {
        if (currentAlias(context) == aliasClassName) return
        val pm = context.packageManager
        try {
            setEnabled(pm, context, fullName(context, aliasClassName), PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
        } catch (e: Exception) {
            return
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(PREF_KEY, aliasClassName).apply()
        pendingDisable = ICONS.map { it.aliasClassName }.filter { it != aliasClassName }
    }

    /**
     * Phase 2: call from MainActivity.onStop(). Disables old aliases after
     * the app is backgrounded (safe — launcher re-renders on PACKAGE_CHANGED).
     */
    fun flushPendingCleanup(context: Context) {
        val pending = pendingDisable ?: return
        pendingDisable = null
        val pm = context.packageManager
        for (alias in pending) {
            try {
                val cn = ComponentName(context, fullName(context, alias))
                if (pm.getComponentEnabledSetting(cn) !=
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED) {
                    setEnabled(pm, context, fullName(context, alias), PackageManager.COMPONENT_ENABLED_STATE_DISABLED)
                }
            } catch (e: Exception) {
                // Ignore — alias may not exist on this build.
            }
        }
    }

    /** Re-assert the persisted choice on cold start (survives reboot). */
    fun reassertOnStartup(context: Context) {
        val saved = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(PREF_KEY, null) ?: return
        val pm = context.packageManager
        try {
            if (pm.getComponentEnabledSetting(ComponentName(context, fullName(context, saved))) !=
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED) {
                setEnabled(pm, context, fullName(context, saved), PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
                pendingDisable = ICONS.map { it.aliasClassName }.filter { it != saved }
                flushPendingCleanup(context)
            }
        } catch (e: Exception) {
            // Ignore — alias may not exist on this build.
        }
    }

    private fun setEnabled(pm: PackageManager, context: Context, alias: String, state: Int) {
        pm.setComponentEnabledSetting(
            ComponentName(context, alias),
            state,
            PackageManager.DONT_KILL_APP,
        )
    }
}
