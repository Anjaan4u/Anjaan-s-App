package com.music.bitchord.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.QueueMusic
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.music.bitchord.R
import com.music.bitchord.data.spotify.LocalPlaylist
import com.music.bitchord.data.spotify.LocalPlaylistStore

/**
 * Simple reorder screen for local playlists. Tap the up/down arrows to move
 * a playlist; the order saves instantly. No drag gestures — reliable.
 */
@Composable
fun ReorderPlaylistsScreen(
    contentPadding: PaddingValues,
    onDone: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val playlists by LocalPlaylistStore.playlists.collectAsStateWithLifecycle()
    val hiddenIds by LocalPlaylistStore.hiddenIds.collectAsStateWithLifecycle()
    var ordered by remember(playlists, hiddenIds) {
        mutableStateOf(playlists.filterNot { it.id in hiddenIds })
    }

    fun persist(newOrder: List<LocalPlaylist>) {
        ordered = newOrder
        val current = LocalPlaylistStore.playlists.value.toMutableList()
        val visibleIds = newOrder.map { it.id }.toSet()
        val hidden = current.filter { it.id !in visibleIds }
        LocalPlaylistStore.replaceAll(newOrder + hidden)
    }

    fun moveUp(index: Int) {
        if (index <= 0) return
        val newList = ordered.toMutableList()
        val item = newList.removeAt(index)
        newList.add(index - 1, item)
        persist(newList)
    }

    fun moveDown(index: Int) {
        if (index >= ordered.size - 1) return
        val newList = ordered.toMutableList()
        val item = newList.removeAt(index)
        newList.add(index + 1, item)
        persist(newList)
    }

    Column(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(
                top = contentPadding.calculateTopPadding() + 8.dp,
                bottom = 16.dp,
                start = 16.dp,
                end = 16.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            items(ordered, key = { it.id }) { playlist ->
                val index = ordered.indexOf(playlist)
                PlaylistReorderRow(
                    playlist = playlist,
                    canMoveUp = index > 0,
                    canMoveDown = index < ordered.size - 1,
                    onMoveUp = { moveUp(index) },
                    onMoveDown = { moveDown(index) },
                )
            }
        }
        Button(
            onClick = onDone,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
        ) {
            Text(stringResource(R.string.done))
        }
    }
}

@Composable
private fun PlaylistReorderRow(
    playlist: LocalPlaylist,
    canMoveUp: Boolean,
    canMoveDown: Boolean,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(
                MaterialTheme.colorScheme.surfaceVariant,
                RoundedCornerShape(12.dp),
            )
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            Icons.Rounded.QueueMusic,
            contentDescription = null,
            modifier = Modifier.size(40.dp),
            tint = MaterialTheme.colorScheme.primary,
        )
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                text = playlist.title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
            )
            Text(
                text = "${playlist.songs.size} songs",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        IconButton(
            onClick = onMoveUp,
            enabled = canMoveUp,
        ) {
            Icon(
                Icons.Rounded.KeyboardArrowUp,
                contentDescription = null,
            )
        }
        IconButton(
            onClick = onMoveDown,
            enabled = canMoveDown,
        ) {
            Icon(
                Icons.Rounded.KeyboardArrowDown,
                contentDescription = null,
            )
        }
    }
}
