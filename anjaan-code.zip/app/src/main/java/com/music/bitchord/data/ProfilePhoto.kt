package com.music.bitchord.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

/**
 * Local profile photo (guest mode — no login needed).
 *
 * The photo is copied into the app's private files dir, so it survives
 * gallery changes and doesn't need storage permission to display.
 * [version] bumps on every change so Compose UI recomposes.
 */
object ProfilePhoto {
    private const val FILE_NAME = "profile_photo.jpg"

    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version.asStateFlow()

    /** The saved photo file, or null if none set. */
    fun file(context: Context): File? {
        val f = File(context.filesDir, FILE_NAME)
        return if (f.exists()) f else null
    }

    /**
     * Copy the picked image into private storage.
     * Returns true on success.
     */
    fun save(context: Context, uri: Uri): Boolean {
        return try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                File(context.filesDir, FILE_NAME).outputStream().use { output ->
                    input.copyTo(output)
                }
            } ?: return false
            _version.value += 1
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Remove the saved photo. */
    fun clear(context: Context) {
        try {
            File(context.filesDir, FILE_NAME).delete()
        } catch (e: Exception) {
            // Best effort.
        }
        _version.value += 1
    }
}
