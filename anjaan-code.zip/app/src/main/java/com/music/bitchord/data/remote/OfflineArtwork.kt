package com.music.bitchord.data.remote

import android.content.Context
import android.content.SharedPreferences
import coil3.intercept.Interceptor
import coil3.request.ImageResult
import java.io.File
import java.net.URL
import java.security.MessageDigest
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Offline artwork sidecars for cached songs.
 *
 * When a streamed song plays, its cover is downloaded once and filed here
 * next to the cached audio so the player, queue and notification keep their
 * artwork with no network at all — after "Clear cache" wipes Coil's own disk
 * cache, in airplane mode, anywhere.
 *
 * Storage is the app-data directory ([Context.getFilesDir]), never the cache
 * directory: the system's "Clear cache" button and phone-cleaner apps wipe
 * the latter, while this survives everything short of "Clear data" or an
 * uninstall.
 *
 * Two read paths share the store:
 *  - [localUriFor]: explicit lookup by track id, used by
 *    `rememberRemoteArtworkUrl` so the main player resolves offline first.
 *  - [Interceptor]: a Coil interceptor that rewrites any image request whose
 *    URL maps to a stored cover, covering every other surface (rows, mini
 *    player, notification) with no UI changes.
 *
 * Everything here never throws; a missing or corrupt sidecar simply means
 * the normal network path runs.
 */
object OfflineArtwork {

    private const val DIR_NAME = "artwork"
    private const val PREFS_NAME = "offline_artwork"
    private const val KEY_URL_PREFIX = "url:"

    /** Application context, set once at app start. Lets non-UI code (e.g. [Song.toMediaItem]) resolve offline artwork without a Context. */
    private var appContext: android.content.Context? = null

    fun init(context: android.content.Context) {
        appContext = context.applicationContext
    }

    /**
     * Size hints embedded in artwork URLs (`w60-h60` style). Callers size the
     * same URL per surface via `artworkAt()`, so the request URL rarely equals
     * the raw URL recorded at play time — normalize both sides to one key so
     * every sized variant maps to the stored cover.
     */
    private val SIZE_HINT = Regex("""w\d+-h\d+""")
    private fun normUrl(url: String): String = url.replace(SIZE_HINT, "w0-h0")

    /** Soft ceiling for the artwork dir; oldest files go first. */
    private const val MAX_DIR_BYTES = 150L * 1024 * 1024

    /** Hard cap on a single download, so a hostile URL can't fill storage. */
    private const val MAX_DOWNLOAD_BYTES = 2L * 1024 * 1024

    private fun dir(context: Context): File =
        File(context.filesDir, DIR_NAME).apply { mkdirs() }

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private fun fileFor(context: Context, videoId: String): File =
        File(dir(context), "${sha1(videoId)}.jpg")

    /**
     * A `file://` URI for [videoId]'s stored cover, or null when there is
     * none. Used by the player's artwork resolution.
     */
    fun localUriFor(context: Context, videoId: String): String? {
        if (videoId.isBlank()) return null
        val file = fileFor(context, videoId)
        return if (file.isFile && file.length() > 0) "file://${file.absolutePath}" else null
    }

    /**
     * Same as [localUriFor] but uses the init-time application context.
     * For non-UI code (e.g. `Song.toMediaItem`) that has no Context in hand.
     */
    fun localUriFor(videoId: String): String? {
        val ctx = appContext ?: return null
        return localUriFor(ctx, videoId)
    }

    /**
     * Whether [videoId] has a stored cover. Used to retry downloads for
     * cached songs whose artwork went missing (failed download, pruned, …).
     */
    fun hasArtwork(context: Context, videoId: String): Boolean {
        if (videoId.isBlank()) return false
        val file = fileFor(context.applicationContext, videoId)
        return file.isFile && file.length() > 0
    }

    /**
     * Makes sure [thumbnailUrl]'s cover is stored for [videoId]. Downloads it
     * the first time only; later calls are a cheap existence check. Records
     * the URL so the [Interceptor] can map requests back to the file.
     * Fire-and-forget safe: never throws.
     */
    suspend fun ensure(context: Context, videoId: String, thumbnailUrl: String?) {
        // Persistent caching is off: don't save artwork to disk.
        if (!com.music.bitchord.data.settings.AppSettings.cachePlayedSongs.value) return

        if (videoId.isBlank() || thumbnailUrl.isNullOrBlank()) return
        val appContext = context.applicationContext
        // Record the mapping even on a hit: cheap, and it heals entries
        // written before the map existed. Keyed on the normalized URL so the
        // sized variants every surface requests all hit the same entry.
        prefs(appContext).edit().putString(KEY_URL_PREFIX + normUrl(thumbnailUrl), videoId).apply()
        val file = fileFor(appContext, videoId)
        if (file.isFile && file.length() > 0) return
        withContext(Dispatchers.IO) {
            runCatching {
                val tmp = File(file.parent, "${file.name}.tmp")
                URL(thumbnailUrl).openConnection().run {
                    connectTimeout = 10_000
                    readTimeout = 15_000
                    setRequestProperty("User-Agent", "Mozilla/5.0")
                    getInputStream().use { input ->
                        tmp.outputStream().use { output ->
                            val buf = ByteArray(32 * 1024)
                            var total = 0L
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                total += n
                                if (total > MAX_DOWNLOAD_BYTES) {
                                    throw IllegalStateException("artwork too large")
                                }
                                output.write(buf, 0, n)
                            }
                        }
                    }
                }
                if (tmp.length() > 0 && (tmp.renameTo(file) || run { file.delete(); tmp.renameTo(file) })) {
                    prune(appContext)
                } else {
                    tmp.delete()
                }
            }.onFailure {
                runCatching { File(file.parent, "${file.name}.tmp").delete() }
            }
        }
    }

    /**
     * Maps a Coil request model to a stored cover file, or null. Handles
     * plain URL strings (the common case) via the recorded URL map, plus
     * `file://` models which are already offline.
     */
    fun resolveFile(context: Context, data: Any?): File? {
        val url = data as? String ?: return null
        if (!url.startsWith("http")) return null
        val videoId = prefs(context).getString(KEY_URL_PREFIX + normUrl(url), null)
            // YouTube thumbnails embed the id; no map entry needed.
            ?: ytIdFromUrl(url)
            ?: return null
        val file = fileFor(context, videoId)
        return if (file.isFile && file.length() > 0) file else null
    }

    /** Drops every stored cover. Used by "Clear song cache". Never throws. */
    fun clearAll(context: Context) {
        runCatching {
            dir(context).deleteRecursively()
            prefs(context).edit().clear().apply()
        }
    }

    private fun ytIdFromUrl(url: String): String? {
        // https://i.ytimg.com/vi/<id>/hqdefault.jpg (also i9.ytimg.com etc.)
        val m = Regex("""ytimg\.com/vi/([^/?#&]+)""").find(url) ?: return null
        return m.groupValues[1].takeIf { it.isNotBlank() }
    }

    private fun prune(context: Context) {
        runCatching {
            val files = dir(context).listFiles()
                ?.filter { it.isFile && !it.name.endsWith(".tmp") }
                .orEmpty()
            var total = files.sumOf { it.length() }
            if (total <= MAX_DIR_BYTES) return
            for (f in files.sortedBy { it.lastModified() }) {
                if (total <= MAX_DIR_BYTES) break
                total -= f.length()
                f.delete()
            }
        }
    }

    private fun sha1(s: String): String {
        val bytes = MessageDigest.getInstance("SHA-1")
            .digest(s.toByteArray(Charsets.UTF_8))
        return buildString(bytes.size * 2) {
            for (b in bytes) append(String.format(Locale.ROOT, "%02x", b))
        }
    }

    /**
     * Coil interceptor: serves stored covers from app data instead of the
     * network. Coil's own disk cache lives in the cache directory and dies
     * with "Clear cache"; this keeps artwork working after that and offline.
     * Requests with no stored cover pass through untouched.
     */
    class Interceptor(private val context: Context) : coil3.intercept.Interceptor {
        override suspend fun intercept(chain: coil3.intercept.Interceptor.Chain): ImageResult {
            // The offline lookup must never break the network path: any
            // failure here (bad prefs, odd model type) falls through to a
            // normal network load instead of a blank image.
            val file = runCatching {
                resolveFile(context.applicationContext, chain.request.data)
            }.getOrNull()
            if (file != null) {
                val redirected = chain.request.newBuilder().data(file).build()
                return chain.withRequest(redirected).proceed()
            }
            return chain.proceed()
        }
    }
}
