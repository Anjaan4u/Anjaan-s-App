package com.music.bitchord.data.spotify

import android.content.Context
import android.content.SharedPreferences
import com.music.bitchord.data.model.LikeStatus
import com.music.bitchord.data.model.Song
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * Local liked songs for guests (no YouTube Music login).
 *
 * Stores liked video IDs with song metadata in SharedPreferences, so the
 * heart in the player works without an account and the Library can show
 * a "Liked Songs" shelf. Signed-in users keep using YouTube's liked list;
 * this store is only consulted when there is no active session.
 */
object LocalLikeStore {
    private const val PREF_NAME = "bitchord_local_likes"
    private const val KEY_LIKES = "likes_json"

    private lateinit var prefs: SharedPreferences

    private val _likedSongs = MutableStateFlow<List<Song>>(emptyList())
    val likedSongs = _likedSongs.asStateFlow()

    /** videoId -> LikeStatus for quick lookup */
    private val _likeStatuses = MutableStateFlow<Map<String, LikeStatus>>(emptyMap())
    val likeStatuses = _likeStatuses.asStateFlow()

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        load()
    }

    private fun load() {
        if (!this::prefs.isInitialized) return
        val raw = prefs.getString(KEY_LIKES, null) ?: return
        runCatching {
            val songs = mutableListOf<Song>()
            val jsonArray = JSONArray(raw)
            for (i in 0 until jsonArray.length()) {
                val sObj = jsonArray.getJSONObject(i)
                songs.add(
                    Song(
                        videoId = sObj.optString("videoId", ""),
                        title = sObj.optString("title", ""),
                        artist = sObj.optString("artist", ""),
                        thumbnailUrl = sObj.optString("thumbnailUrl", null)
                            .takeIf { !it.isNullOrBlank() && it != "null" },
                        durationText = sObj.optString("durationText", null)
                            .takeIf { !it.isNullOrBlank() && it != "null" },
                        artistId = sObj.optString("artistId", null)
                            .takeIf { !it.isNullOrBlank() && it != "null" },
                        albumId = sObj.optString("albumId", null)
                            .takeIf { !it.isNullOrBlank() && it != "null" },
                        albumName = sObj.optString("albumName", null)
                            .takeIf { !it.isNullOrBlank() && it != "null" },
                        isVideo = sObj.optBoolean("isVideo", false),
                    ),
                )
            }
            _likedSongs.value = songs
            _likeStatuses.value = songs.associate { it.videoId to LikeStatus.LIKE }
        }
    }

    /** Toggle: returns true if now liked, false if unliked. */
    fun toggleLike(song: Song): Boolean {
        val current = _likedSongs.value
        return if (current.any { it.videoId == song.videoId }) {
            unlike(song.videoId)
            false
        } else {
            like(song)
            true
        }
    }

    fun like(song: Song) {
        if (song.videoId.isBlank()) return
        if (_likedSongs.value.any { it.videoId == song.videoId }) return
        val updated = listOf(song) + _likedSongs.value
        _likedSongs.value = updated
        _likeStatuses.value = _likeStatuses.value + (song.videoId to LikeStatus.LIKE)
        persist(updated)
    }

    fun unlike(videoId: String) {
        val updated = _likedSongs.value.filterNot { it.videoId == videoId }
        if (updated.size == _likedSongs.value.size) return
        _likedSongs.value = updated
        _likeStatuses.value = _likeStatuses.value - videoId
        persist(updated)
    }

    /** Replaces every liked song (backup restore). Never throws. */
    fun replaceAll(songs: List<Song>) {
        val clean = songs.filter { it.videoId.isNotBlank() }.distinctBy { it.videoId }
        _likedSongs.value = clean
        _likeStatuses.value = clean.associate { it.videoId to LikeStatus.LIKE }
        persist(clean)
    }

    fun isLiked(videoId: String): Boolean =
        _likeStatuses.value[videoId] == LikeStatus.LIKE

    fun likeStatusOf(videoId: String): LikeStatus =
        _likeStatuses.value[videoId] ?: LikeStatus.INDIFFERENT

    private fun persist(songs: List<Song>) {
        if (!this::prefs.isInitialized) return
        runCatching {
            val jsonArray = JSONArray()
            for (song in songs) {
                val sObj = JSONObject()
                sObj.put("videoId", song.videoId)
                sObj.put("title", song.title)
                sObj.put("artist", song.artist)
                sObj.put("thumbnailUrl", song.thumbnailUrl)
                sObj.put("durationText", song.durationText)
                sObj.put("artistId", song.artistId)
                sObj.put("albumId", song.albumId)
                sObj.put("albumName", song.albumName)
                sObj.put("isVideo", song.isVideo)
                jsonArray.put(sObj)
            }
            prefs.edit().putString(KEY_LIKES, jsonArray.toString()).apply()
        }
    }
}
